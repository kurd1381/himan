# Tabchi V1.0
ادیت شده توسط تله گیمر

## نحوه نصب
```bash
git clone https://github.com/tabchis/tabchi.git && cd tabchi && chmod 777 install.sh && chmod 777 hemanhack.sh && ./install.sh && lua creator.lua
```
## ساخت ربات!
```
lua creator.lua
Auto Detected Tabchi ID : 0
Enter Full Sudo ID : شناسه خودتان
Done!
New Tabchi Created...
ID : 0
Full Sudo : شناسه شما
Run : ./tabchi-0.sh
```
شما میتوانید شناسه عددی خودرا از @USERinfoBot در تلگرام دریافت کنید

## راه اندازی
برای راه اندازی دستور 
./tabchi-id.sh
دریافت کردید بزنید(Auto Detected Tabchi ID)ایدی که در قسمت(id)را باید بزنید که به جای

## روشن بودن خودکار
برای اتو لانج یا روشن بودن خودکار دستور زیر را وارد کنید در پوشه تبچی
./hemanhack.sh

#### channel      [hemanhack](https://telegram.me/hemanhack)

